using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEngine;
using UnityEngine.Jobs;

public class PlayerController : MonoBehaviour
{
    public float power = 0.75f;
    private float oldPower = 0.75f;
    public new Rigidbody rigidbody;

    ChangeGravity changeGravity;

    //���@�{�̂ƃJ�����̃I�u�W�F�N�g
    GameObject player;
    GameObject mainCamera;

    //�����݂̏d�͂̕��� 0���牺�E�㍶��O���̏�
    int underNum = 0;

    //�����邩�ǂ����̃t���O
    bool canMove = true;

    // Start is called before the first frame update
    void Start()
    {
        changeGravity = GetComponent<ChangeGravity>();
        //�I�u�W�F�N�g�w��
        player = this.gameObject;
        mainCamera = GameObject.FindGameObjectWithTag("MainCamera");
    }

    //�d�͕����擾
    public int GetNum()
    {
        return underNum;
    }
    //�t���O�擾
    public bool GetCanMove()
    {
        return canMove;
    }
    //�t���O���
    public void SendCanMoveFlag(bool flag)
    {
        canMove = flag;
    }

    //�΂ߌ�������
    private void DiagonalDeceleration(bool key1, bool key2, bool key3, bool key4)
    {
        if (key1 && key2 || key1 && key4 || key3 && key2 || key3 && key4)
        {
            power = oldPower * 0.65f;
        }
        else
        {
            power = oldPower;
        }
    }

    // Update is called once per frame
    void Update()
    {
        changeGravity.Update();

        if (changeGravity.GetGravity().y < 0)
        {
            underNum = 0;
            player.transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (changeGravity.GetGravity().y > 0)
        {
            underNum = 1;
            player.transform.rotation = Quaternion.Euler(0, 0, 180);
        }
        else if (changeGravity.GetGravity().x < 0)
        {
            underNum = 2;
            player.transform.rotation = Quaternion.Euler(0, 0, -90);
        }

        else if (changeGravity.GetGravity().x > 0)
        {
            underNum = 3;
            player.transform.rotation = Quaternion.Euler(0, 0, 90);
        }
        else if (changeGravity.GetGravity().z < 0)
        {
            underNum = 4;
            player.transform.rotation = Quaternion.Euler(-90, 0, 0);
        }
        else if (changeGravity.GetGravity().z > 0)
        {
            underNum = 5;
            player.transform.rotation = Quaternion.Euler(90, 0, 0);
        }
        //�΂ߌ�������
        DiagonalDeceleration(Input.GetKey(KeyCode.W), Input.GetKey(KeyCode.A), Input.GetKey(KeyCode.S), Input.GetKey(KeyCode.D));
    }

    public void ChangeGravity(int direction)
    {
        changeGravity.GravityDirection(direction);
    }

   
}
