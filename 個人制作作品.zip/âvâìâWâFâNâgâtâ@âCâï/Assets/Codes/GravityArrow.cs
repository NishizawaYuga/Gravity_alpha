using System.Collections;
using System.Collections.Generic;
//using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class GravityArrow : MonoBehaviour
{
    [SerializeField]
    [Tooltip("�N���O�̏d�ʕ����A��͑��Ɠ���")]
    private int startDirection;

    [SerializeField]
    [Tooltip("�N����̏d�ʕ����A��͑��Ɠ���")]
    private int endDirection;

    //�v���C���[�I�u�W�F�N�g
    [SerializeField]
    [Tooltip("�v���C���[�I�u�W�F�N�g")]
    private GameObject player;

    //�J����
    [SerializeField]
    [Tooltip("�J����")]
    private GameObject mainCamera;

    //�X�N���v�g
    private ChangeGravity cg;           //�d�͕���
    private CaemeraFollowTarget cF;     //�J�����Ǐ]����
    //private CameraFollow cF;
    private Easing ease;                //�C�[�W���O

    //�N���t���O
    bool isStartUp = false;
    //�����n�_�ƏI���_���i�[����ϐ�
    Vector3 startPos;
    Quaternion startRot;
    Vector3 endPos;
    Quaternion endRot;
    private float nowTime = 0f;            //�o�ߎ���
    private float maxTime = 0f;     //�ړ�����
    private float rotateTime = 0f;
    private bool isRotate = false;


    void Start()
    {
        //�X�N���v�g�o�^
        cg = player.GetComponent<ChangeGravity>();
        cF = mainCamera.GetComponent<CaemeraFollowTarget>();
        //cF = mainCamera.GetComponent<CameraFollow>();
        ease = new Easing();
        if (endDirection - startDirection == 1 || endDirection - startDirection == -1)
        {
            maxTime = 180f;
        }
        else
        {
            maxTime = 90f;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (isStartUp)
        {
            //if (cF.GetRotation() != endRot)
            if (nowTime < maxTime)
            {
                //cF.SetPos();
                RotateObject();
                nowTime += 1f;
            }
            else
            {
                isRotate = true;
                nowTime = 0;
                isStartUp = false;
                cF.IsFollow(true);
                cg.GravityDirection(endDirection);                
                //this.gameObject.transform.rotation = endRot;
            }
        }
        if (isRotate)
        {
            if (rotateTime < maxTime)
            {
                //cF.SetPos();
                //if (rotateTime * 4 < maxTime)
                {
                    cF.transform.rotation = Quaternion.Euler(0f, 0f, rotateTime);
                }
                //cF.SetOffset(cF.GetVector(startDirection) + cF.GetVector(endDirection) / maxTime * rotateTime);
                //cF.SetOffset(cF.GetVector(startDirection) - cF.GetVector(endDirection) / maxTime * rotateTime);
                //cF.transform.position = (ease.OutQuadVec3(cF.GetVector(startDirection) - cF.GetVector(endDirection), cF.GetVector(startDirection), maxTime, rotateTime));
                //Vector3 test = new Vector3(ease.OutQuad(cF.GetVector(startDirection).x - cF.GetVector(endDirection).x, cF.GetVector(startDirection).x, maxTime, rotateTime),
                //    ease.OutQuad(cF.GetVector(startDirection).y - cF.GetVector(endDirection).y, cF.GetVector(startDirection).y, maxTime, rotateTime),
                //    ease.OutQuad(cF.GetVector(startDirection).z - cF.GetVector(endDirection).z, cF.GetVector(startDirection).z, maxTime, rotateTime));
                //cF.transform.position = (ease.OutQuadVec3(player.transform.position - cF.GetVector(startDirection) - cF.GetVector(endDirection),player.transform.position - cF.GetVector(startDirection),maxTime,rotateTime));
                //cF.transform.position = new Vector3(0, -10f, 0);
                rotateTime += 1f;
            }
            else
            {
                cF.IsDefault(true);
                rotateTime = 0f;
                isRotate = false;
                //cF.SetPos(player.transform.position - cF.GetVector(endDirection) / 2);
            }
        }
    }


    public void ChangeGravity()
    {
        if (!isStartUp)
        {
            isStartUp = true;
            //cF.IsFollow(false);
            //cF.IsDefault(false);
            startPos = cF.GetVector();
            //startRot = cF.GetRotation();
            startRot = Quaternion.Euler(0, 0, 0);
            //endRot = cF.GetEndRotation(endDirection);
            endRot = Quaternion.Euler(0, 0, 180);
        }
    }
    private void RotateObject()
    {
        if(endDirection < 2)
        {
            if (endDirection % 2 == 0)
            {
                this.gameObject.transform.rotation = Quaternion.Euler(-nowTime, 0f, 0f);
            }
            else
            {
                this.gameObject.transform.rotation = Quaternion.Euler(nowTime, 0f, 0f);
            }
        }
        else if (endDirection > 1 && endDirection < 4)
        {
            if (endDirection % 2 == 0)
            {
                this.gameObject.transform.rotation = Quaternion.Euler(0f, 0f, -nowTime);
            }
            else
            {
                this.gameObject.transform.rotation = Quaternion.Euler(0f, 0f, nowTime);
            }
        }
        else
        {
            if (endDirection % 2 == 0)
            {
                this.gameObject.transform.rotation = Quaternion.Euler(nowTime, 0f, 0f);
            }
            else
            {
                this.gameObject.transform.rotation = Quaternion.Euler(-nowTime, 0f, 0f);
            }
        }
    }
}
