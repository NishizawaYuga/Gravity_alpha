using System.Collections;
using System.Collections.Generic;
//using System.Numerics;
using UnityEngine;

public class CaemeraFollowTarget : MonoBehaviour
{
    //�I�u�W�F�N�g
    [SerializeField]
    [Tooltip("testplayer")]
    private GameObject target;

    //�X�N���v�g
    PlayerController script;

    //���W�Ɖ�]
    private Vector3 offset;
    private Vector3 rotation;

    //�Ǐ]���邩�ǂ���
    bool isFollow = true;

    //�J������]�i�蓮�j
    float rotY = 0f;


    //PV�p
    private float posZ = 1.0f;

    // Start is called before the first frame update
    void Start()
    {
        //�Q�[���J�n���_�̃J�����ƃ^�[�Q�b�g�̋���
        offset = gameObject.transform.position - target.transform.position;
        //�X�N���v�g�o�^
        script = target.GetComponent<PlayerController>();
    }

    private void UpdatePos(float x, float y, float z)
    {
        //��Ƀ^�[�Q�b�g�����苗������
        //�����őł���������t�]������
        Vector3 pos = new Vector3(x * 1.0f, y * 1.0f, z * posZ);
        //���΍��W�ŃJ�����̍��W�����߂�
        pos += target.transform.position;

        offset = pos - target.transform.position;

        //PV�p
        if (Input.GetKey(KeyCode.Q))
        {
            posZ += 0.01f;
        }
    }

    //�v���C���[���ړ�������ɃJ�������ړ�����悤�ɂ���
    private void LateUpdate()
    {
        int underNum = script.GetNum();
        if (Input.GetKey(KeyCode.LeftArrow)) 
        {
            if(underNum == 0)
            {
                //rotY -= 0.5f;
            }
        }
        if (isFollow)
        {
            //�J�����̈ʒu���^�[�Q�b�g�̈ʒu�ɃI�t�Z�b�g�𑫂����ꏊ�ɂ���
            gameObject.transform.position = target.transform.position + offset;

            //�J�����̉�]
            //�d�́F��
            if (underNum == 0)
            {
                gameObject.transform.rotation = Quaternion.Euler(0, 0, 0);
                //gameObject.transform.RotateAround(target.transform.position, Vector3.up, 0.1f);
                UpdatePos(0.0f, 0.25f, -1.0f);
            }
            //�d�́F��
            else if (underNum == 1)
            {
                gameObject.transform.rotation = Quaternion.Euler(0, 0, 180);
                UpdatePos(0.0f, -0.25f, -1.0f);
            }
            //�d�́F��
            else if (underNum == 2)
            {
                gameObject.transform.rotation = Quaternion.Euler(0, 0, -90);
                UpdatePos(0.25f, 0.0f, -1.0f);
            }
            //�d�́F�E
            else if (underNum == 3)
            {
                gameObject.transform.rotation = Quaternion.Euler(0, 0, 90);
                UpdatePos(-0.25f, 0.0f, -1.0f);
            }
            //�d�́F��O
            else if (underNum == 4)
            {
                gameObject.transform.rotation = Quaternion.Euler(90, 0, 0);
                UpdatePos(0.0f, 1.0f, 0.25f);
            }
            //�d�́F��
            else if (underNum == 5)
            {
                gameObject.transform.rotation = Quaternion.Euler(-90, 0, 0);
                UpdatePos(0.0f, -1.0f, -0.25f);
            }
        }
    }

    public void ChangeCameraRotation(int underNum)
    {
        //�J�����̉�]
        //�d�́F��
        if (underNum == 0)
        {
            gameObject.transform.rotation = Quaternion.Euler(0, 0, 0);
            UpdatePos(0.0f, 0.25f, -1.0f);
        }
        //�d�́F��
        else if (underNum == 1)
        {
            gameObject.transform.rotation = Quaternion.Euler(0, 0, 180);
            UpdatePos(0.0f, -0.25f, -1.0f);
        }
        //�d�́F��
        else if (underNum == 2)
        {
            gameObject.transform.rotation = Quaternion.Euler(0, 0, -90);
            UpdatePos(0.25f, 0.0f, -1.0f);
        }
        //�d�́F�E
        else if (underNum == 3)
        {
            gameObject.transform.rotation = Quaternion.Euler(0, 0, 90);
            UpdatePos(-0.25f, 0.0f, -1.0f);
        }
        //�d�́F��O
        else if (underNum == 4)
        {
            gameObject.transform.rotation = Quaternion.Euler(90, 0, 0);
            UpdatePos(0.0f, 1.0f, 0.25f);
        }
        //�d�́F��
        else if (underNum == 5)
        {
            gameObject.transform.rotation = Quaternion.Euler(-90, 0, 0);
            UpdatePos(0.0f, -1.0f, -0.25f);
        }
    }
    public void IsFollow(bool change)
    {
        isFollow = change;
    }
    public void SetPos()
    {
        gameObject.transform.position = target.transform.position + offset;
    }
    public void SetRotNum(float x,float y,float z)
    {
        gameObject.transform.rotation = Quaternion.Euler(x, y, z);
    }
    public Vector3 GetVector()
    {
        return gameObject.transform.position;
    }
    public Quaternion GetRotation()
    {
        return gameObject.transform.rotation;
    }
    public Quaternion GetEndRotation(int num)
    {
        Quaternion quaternion = Quaternion.identity;

        if (num == 0)
        {
            quaternion = Quaternion.Euler(0, 0, 0);
        }
        else if (num == 1)
        {
            quaternion = Quaternion.Euler(0, 0, 180);
        }
        else if (num == 2)
        {
            quaternion = Quaternion.Euler(0, 0, -90);
        }
        else if (num == 3)
        {
            quaternion = Quaternion.Euler(0, 0, 90);
        }
        else if (num == 4)
        {
            quaternion = Quaternion.Euler(90, 0, 0);
        }
        else if (num == 5)
        {
            quaternion = Quaternion.Euler(-90, 0, 0);
        }
        return quaternion;
    }
}
