using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    //�����ϐ�
    float rotY = 0f;

    //�N���A�t���O
    bool isClear = false;

    GameObject goal;

    [SerializeField]
    [Tooltip("�ς��ӏ��͉�]����")]
    private int direction;

    void Start()
    {
        goal = this.gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        rotY += 0.8f;
        if (direction == 0)
        {
            goal.transform.rotation = Quaternion.Euler(0, rotY, 0);
        }
        else if (direction == 1)
        {
            goal.transform.rotation = Quaternion.Euler(0, rotY, 0);
        }
        else if (direction == 2)
        {
            goal.transform.rotation = Quaternion.Euler(rotY, 0, 0);
        }
        else if (direction == 3)
        {
            goal.transform.rotation = Quaternion.Euler(rotY, 0, 0);
        }
        else if (direction == 4)
        {
            goal.transform.rotation = Quaternion.Euler(rotY, 90, 0);
        }
        else if (direction == 5)
        {
            goal.transform.rotation = Quaternion.Euler(rotY, -90, 0);
        }

        if (rotY > 180f)
        {
            rotY = -180f;
        }
    }
    public void GetStar()
    {
        goal.SetActive(false);
        isClear = true;
    }
}
